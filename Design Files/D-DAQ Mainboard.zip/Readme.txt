The contents of this zip file are released under the CERN OHL v1.2
For more information, please visit:
http://www.ohwr.org/projects/cernohl/wiki

If you wish to distribute this file, this Readme.txt and all stated files must be included.

D-DAQ Mainboard.zip Contexts:

cern_ohl_v_1_2.txt
D-DAQ Mainboard - Trace Match.dsn
D-DAQ Mainboard.brd
D-DAQ Mainboard.sch
D-DAQ OSH Park 7x7.dru
Parts for D-DAQ.lbr
Readme.txt